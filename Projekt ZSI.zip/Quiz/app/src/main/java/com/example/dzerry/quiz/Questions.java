package com.example.dzerry.quiz;


public class Questions {

    public String myQuestions[]={
            "Kiedy Microsoft Azure został wydany?",
            "Na jakiej licencji dostępny jest Microsoft Azure?",
            "Co oznacza skrót PaaS?",
            "Jakiej technologi używa SQL Database?",
            "W ilu regionach świata jest dostępny Azure?",
    };

    private String myChoices[][]={
            {"1 luty 2010","10 październik 2008","15 czerwiec 2012","25 marzec 2014"},
            {"Closed source - platform, Open source - client SDKs","Closed source","Open Source","Closed source - clien SDKs, Open source - platform"},
            {"Platform as a Service","Platform and a SQL","Product and a Service","Product and a SQL"},
            {"Microsoft SQL Server","Cosmos DB","MySQL","Postgresql"},
            {"36","32","33","34"},

    };

    private String myCorrectAnswers[]={"1 luty 2010","Closed source - platform, Open source - client SDKs","Platform as a Service","Microsoft SQL Server","36"};

    public String getQuestion(int a){
        String question=myQuestions[a];
        return question;
    }

    public String getChoice1(int a){
        String choice=myChoices[a][0];
        return choice;
    }
    public String getChoice2(int a){
        String choice=myChoices[a][1];
        return choice;
    }
    public String getChoice3(int a){
        String choice=myChoices[a][2];
        return choice;
    }
    public String getChoice4(int a){
        String choice=myChoices[a][3];
        return choice;
    }

    public  String getCorectAnswer(int a ){
        String answer= myCorrectAnswers[a];
        return answer;
    }

}

